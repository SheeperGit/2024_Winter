package designpatterns;

/**************
 * Before
***************/

/*class TV{
	public void turnOn() {
	}
	
	public void turnOff() {
	}
}

class Heater{
	int temperature;
	
	public void on() {
	}
	
	public void off() {
	}
	
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}
}

class SmartHomeController{
	Heater heater;
	
	public SmartHomeController(Heater heater) {
		this.heater = heater;
	}
	
	public void onClick() {
		heater.on();
		heater.setTemperature(20);
	}
}*/

/**************
 * After
***************/

//Receiver
class TV{
	public void turnOn() {
	}
	
	public void turnOff() {
	}
}

//Receiver
class Heater{
	int temperature;
	
	public void on() {
	}
	
	public void off() {
	}
	
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}
}

abstract class Command{
	public abstract void execute();
}

class HeaterOnCommand extends Command{
	Heater heater;
	
	public HeaterOnCommand(Heater heater) {
		this.heater = heater;
	}
	
	public void execute() {
		heater.on();
		heater.setTemperature(20);
	}
}

//Invoker
//doesn't need to know how to the command is executed
//no changes are required if new devices are introduced
class SmartHomeController{
	Command command; //could have more than one command
	
	public SmartHomeController() {
	}
	
	public void setCommand(Command command) {
		this.command = command;
	}
	
	public void onClick() {
		command.execute();
	}
}

//Client
public class CommandExample {
	public static void main(String [] args) {
		SmartHomeController controller = new SmartHomeController();
		Heater heater = new Heater();
		HeaterOnCommand heaterOn = new HeaterOnCommand(heater);
		controller.setCommand(heaterOn);
		controller.onClick();
	}
}
