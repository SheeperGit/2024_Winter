package designpatterns;

import java.util.ArrayList;
import java.util.List;

abstract class GraphicalObject{
	public abstract void draw();
	
	public void add(GraphicalObject obj) {
	}
}

class Line extends GraphicalObject{
	public void draw() {
		System.out.println("Drawing a line");
	}
}

class Rectangle extends GraphicalObject{
	public void draw() {
		System.out.println("Drawing a rectangle");
	}
}

class Picture extends GraphicalObject{
	List<GraphicalObject> contents;
	
	public Picture() {
		contents = new ArrayList<GraphicalObject>();
	}
	
	public void draw() {
		System.out.println("Drawing a Picture");
		for(GraphicalObject obj:contents)
			obj.draw();
	}
	
	public void add(GraphicalObject obj) {
		contents.add(obj);
	}
}

public class CompositeExample {
	public static void main(String [] args) {
		GraphicalObject line = new Line();
		GraphicalObject rectangle = new Rectangle();
		GraphicalObject picture = new Picture();
		picture.add(line);
		picture.add(rectangle);
		picture.draw();
	}
}
