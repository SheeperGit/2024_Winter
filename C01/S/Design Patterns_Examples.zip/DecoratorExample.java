package designpatterns;

abstract class Venue{
	String address;
	public abstract double computeRentalCost();
}

class BirthdayVenue extends Venue{
	double rentalCost;
	public BirthdayVenue(String address, double rentalCost) {
		this.address = address;
		this.rentalCost = rentalCost;
	}
	
	public double computeRentalCost() {
		return rentalCost;
	}
}

abstract class VenueDecorator extends Venue{
	Venue venue;
}

class BalloonsDecorator extends VenueDecorator{
	public BalloonsDecorator(Venue venue) {
		this.venue = venue;
	}
	
	public double computeRentalCost() {
		return 500 + venue.computeRentalCost();
	}
}

class LightsDecorator extends VenueDecorator{
	public LightsDecorator(Venue venue) {
		this.venue = venue;
	}
	
	public double computeRentalCost() {
		return 1000 + venue.computeRentalCost();
	}
}



public class DecoratorExample {
	public static void main(String [] args) {
		Venue venue = new BirthdayVenue("xyz", 2000);
		venue = new LightsDecorator(venue);
		venue = new BalloonsDecorator(venue);
		System.out.println(venue.computeRentalCost());
	}
}
