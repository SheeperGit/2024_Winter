package designpatterns;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/**************
 * Before
***************/

/*class Book{
	String title;
	
	public Book(String title) {
		this.title = title;
	}
	
	@Override
	public String toString() {
		return title;
	}
}

class BookStore{
	List<Book> books;
	
	public BookStore(List<Book> books) {
		this.books = books;
	}
	
	public List<Book> getBooks() {
		return books;
	}
}

class GroceryItem{
	String description;
	
	public GroceryItem(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return description;
	}
}

class GroceryStore{
	GroceryItem [] items;
	
	public GroceryStore(GroceryItem [] items) {
		this.items = items;
	}
	
	public GroceryItem [] getItems() {
		return items;
	}
}

public class IteratorExample {
	public static BookStore getBookStore() {
		List<Book> books = new ArrayList<Book>();
		books.add(new Book("Book 1"));
		books.add(new Book("Book 2"));
		return new BookStore(books);
	}
	
	public static GroceryStore getGroceryStore() {
		GroceryItem [] items = new GroceryItem[3];
		items[0] = new GroceryItem("Grocery Item 1");
		items[1] = new GroceryItem("Grocery Item 2");
		items[2] = new GroceryItem("Grocery Item 3");
		return new GroceryStore(items);
	}
	
	public static void main(String [] args) {
		BookStore bookStore = getBookStore();
		GroceryStore groceryStore = getGroceryStore();
		
		//iterating over the elements of a bookstore
		List<Book> books = bookStore.getBooks();
		for(Book book:books)
			System.out.println(book);
		
		//another code should be used to iterate over the elements of a grocery store
		//the client should know the specifics of each (e.g. array vs array-list, method names, element types, etc)
		GroceryItem [] items = groceryStore.getItems();
		for(GroceryItem item:items)
			System.out.println(item);
	}
}*/

/**************
 * After
***************/

interface InventoryIterator{
	public InventoryItem next();
	public boolean hasNext();
}

interface Inventory{
	public InventoryIterator createIterator();
}

abstract class InventoryItem{
}

class Book extends InventoryItem{
	String title;
	
	public Book(String title) {
		this.title = title;
	}
	
	@Override
	public String toString() {
		return title;
	}
}

class BookStoreIterator implements InventoryIterator{
	List<Book> books;
	int index;
	
	public BookStoreIterator(List<Book> books) {
		this.books = books;
		this.index = -1;
	}
	
	public Book next() {
		if(!hasNext())
			throw new NoSuchElementException();
		index++;
		return books.get(index);
	}
	
	public boolean hasNext() {
		return index < books.size()-1;
	}
}

class BookStore implements Inventory{
	List<Book> books;
	
	public BookStore(List<Book> books) {
		this.books = books;
	}
	
	public List<Book> getBooks() {
		return books;
	}
	
	public InventoryIterator createIterator(){
		return new BookStoreIterator(books);
	}
}

class GroceryItem extends InventoryItem{
	String description;
	
	public GroceryItem(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return description;
	}
}

class GroceryStoreIterator implements InventoryIterator{
	GroceryItem [] items;
	int index;
	
	public GroceryStoreIterator(GroceryItem [] items) {
		this.items = items;
		this.index = -1;
	}
	
	public GroceryItem next() {
		if(!hasNext())
			throw new NoSuchElementException();
		index++;
		return items[index];
	}
	
	public boolean hasNext() {
		return index < items.length-1;
	}
}

class GroceryStore implements Inventory{
	GroceryItem [] items;
	
	public GroceryStore(GroceryItem [] items) {
		this.items = items;
	}
	
	public GroceryItem [] getItems() {
		return items;
	}
	
	public InventoryIterator createIterator(){
		return new GroceryStoreIterator(items);
	}
}

public class IteratorExample {
	public static BookStore getBookStore() {
		List<Book> books = new ArrayList<Book>();
		books.add(new Book("Book 1"));
		books.add(new Book("Book 2"));
		return new BookStore(books);
	}
	
	public static GroceryStore getGroceryStore() {
		GroceryItem [] items = new GroceryItem[3];
		items[0] = new GroceryItem("Grocery Item 1");
		items[1] = new GroceryItem("Grocery Item 2");
		items[2] = new GroceryItem("Grocery Item 3");
		return new GroceryStore(items);
	}
	
	public static void main(String [] args) {
		Inventory [] stores = new Inventory[2];
		stores[0] = getBookStore();	
		stores[1] = getGroceryStore();
		
		//the same code can be used to iterate over the elements of a bookstore and a grocery store
		for(Inventory store:stores) {
			InventoryIterator iterator = store.createIterator();
			while(iterator.hasNext())
				System.out.println(iterator.next());
		}
	}
}
