package designpatterns;

/**************
 * Before
***************/

/*class Matter{
	int state; //0: solid, 1: liquid, 2: gas
	
	public Matter(int state){
		this.state = state;
	}
	
	public void increaseHeat() {
		if(state<2)
			state++;
	}
	
	public void decreaseHeat() {
		if(state>0)
			state--;
	}
	
	public void displayState() {
		if(state == 0)
			System.out.println("Solid");
		else if(state == 1)
			System.out.println("Liquid");
		else
			System.out.println("Gas");
	}
}*/

/**************
 * After
***************/

abstract class State{
	public abstract void increaseHeat();
	public abstract void decreaseHeat();
	public abstract void displayState();
}

class SolidState extends State{
	Matter matter;
	
	public SolidState(Matter matter) {
		this.matter = matter;
	}
	public void increaseHeat() {
		matter.setState(matter.getLiquidState());
	}
	
	public void decreaseHeat() {
	}
	
	public void displayState() {
		System.out.println("Solid");
	}
}

class LiquidState extends State{
	Matter matter;
	
	public LiquidState(Matter matter) {
		this.matter = matter;
	}
	public void increaseHeat() {
		matter.setState(matter.getGasState());
	}
	
	public void decreaseHeat() {
		matter.setState(matter.getSolidState());
	}
	
	public void displayState() {
		System.out.println("Liquid");
	}
}

class GasState extends State{
	Matter matter;
	
	public GasState(Matter matter) {
		this.matter = matter;
	}
	public void increaseHeat() {
	}
	
	public void decreaseHeat() {
		matter.setState(matter.getLiquidState());
	}
	
	public void displayState() {
		System.out.println("Gas");
	}
}

class Matter{
	State solidState;
	State liquidState;
	State gasState;

	State state;
	
	public Matter() {
		solidState = new SolidState(this);
		liquidState = new LiquidState(this);
		gasState = new GasState(this);
		state = solidState;
	}
	
	public void setState(State state) {
		this.state = state;
	}
	
	public void increaseHeat() {
		state.increaseHeat();
	}
	
	public void decreaseHeat() {
		state.decreaseHeat();
	}
	
	public void displayState() {
		state.displayState();
	}
	
	public State getSolidState() {
		return solidState;
	}
	
	public State getLiquidState() {
		return liquidState;
	}
	
	public State getGasState() {
		return gasState;
	}
}

public class StateExample {
	public static void main(String [] args) {
		Matter matter = new Matter();
		for(int i=0;i<4;i++) {
			matter.displayState();
			matter.increaseHeat();
		}
	}
}
