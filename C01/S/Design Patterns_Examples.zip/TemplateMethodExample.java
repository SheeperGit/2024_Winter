package designpatterns;

import java.util.Scanner;

/**************
 * Before
***************/

/*
class Burger {
	String type;
	
	public void customize() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the burger type: ");
		type = scan.next();
		scan.close();
	}
	
	public void prepare() {
		System.out.println("Preparing " + type + " burger");
	}
	
	public void box() {
		System.out.println("Boxing " + type + " burger");
	}
}

class BurgerStore {
	Burger order() {
		Burger burger = new Burger();
		burger.customize();
		burger.prepare();
		burger.box();
		return burger;
	}
}

class Pizza {
	String type;
	String size;
	
	public void customize() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the pizza type: ");
		type = scan.next();
		System.out.println("Enter the pizza size (small/medium/large): ");
		size = scan.next();
		scan.close();
	}
	
	public void prepare() {
		System.out.println("Preparing " + size + " " + type + " pizza");
	}
	
	public void box() {
		System.out.println("Boxing " + size + " " + type + " pizza");
	}
}

class PizzaStore {
	Pizza order() {
		Pizza pizza = new Pizza();
		pizza.customize();
		pizza.prepare();
		pizza.box();
		return pizza;
	}
}
*/


/**************
 * After
***************/

abstract class FastFood{
	public abstract void customize();
	public abstract void prepare();
	public abstract void box();
}

abstract class FastFoodStore{
	
	//Factory method
	public abstract FastFood createFastFood();
	
	//Template method
	public FastFood order() {
		FastFood fastFood = createFastFood();
		fastFood.customize();
		fastFood.prepare();
		fastFood.box();
		return fastFood;
	}
}

class Burger extends FastFood{
	String type;
	
	public void customize() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the burger type: ");
		type = scan.next();
		scan.close();
	}
	
	public void prepare() {
		System.out.println("Preparing " + type + " burger");
	}
	
	public void box() {
		System.out.println("Boxing " + type + " burger");
	}
}

class BurgerStore extends FastFoodStore{
	public FastFood createFastFood() {
		return new Burger();
	}
}

class Pizza extends FastFood{
	String type;
	String size;
	
	public void customize() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the pizza type: ");
		type = scan.next();
		System.out.println("Enter the pizza size (small/medium/large): ");
		size = scan.next();
		scan.close();
	}
	
	public void prepare() {
		System.out.println("Preparing " + size + " " + type + " pizza");
	}
	
	public void box() {
		System.out.println("Boxing " + size + " " + type + " pizza");
	}
}

class PizzaStore {
	public FastFood createFastFood() {
		return new Pizza();
	}
}

public class TemplateMethodExample {

}
