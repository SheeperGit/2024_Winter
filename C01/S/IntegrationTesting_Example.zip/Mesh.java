import java.util.ArrayList;
import java.util.List;

public class Mesh {
    List<Triangle> triangles;

    public Mesh(){
        triangles = new ArrayList<Triangle>();
    }

    public void add(Triangle triangle){
        triangles.add(triangle);
    }

    public Triangle findTriangleWithLargestPerimeter(){
        if(triangles==null || triangles.size()==0)
            return null;
        Triangle result = triangles.get(0);
        for(int i=1;i<triangles.size();i++){
            if(triangles.get(i).computePerimeter() > result.computePerimeter())
                result = triangles.get(i);
        }
        return result;
    }
}
