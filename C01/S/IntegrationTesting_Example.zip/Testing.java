import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class Testing {

    @Test
    public void check_findTriangleWithLargestPerimeter(){
        Triangle m1 = mock(Triangle.class);
        Triangle m2 = mock(Triangle.class);
        Triangle m3 = mock(Triangle.class);
        when(m1.computePerimeter()).thenReturn(6.5);
        when(m2.computePerimeter()).thenReturn(8.2);
        when(m3.computePerimeter()).thenReturn(3.1);
        Mesh mesh = new Mesh();
        mesh.add(m1);
        mesh.add(m2);
        mesh.add(m3);
        assertEquals(mesh.findTriangleWithLargestPerimeter(), m2);
    }

    @Test
    public void check_computePerimeter(){
        Vertex m1 = mock(Vertex.class);
        Vertex m2 = mock(Vertex.class);
        Vertex m3 = mock(Vertex.class);
        when(m1.computeDistance(m2)).thenReturn(3.0);
        when(m2.computeDistance(m3)).thenReturn(4.0);
        when(m3.computeDistance(m1)).thenReturn(5.0);
        Triangle triangle = new Triangle(m1, m2, m3);
        assertTrue(triangle.computePerimeter()==12);
    }
}