public class Triangle {
    Vertex v1, v2, v3;

    public Triangle(Vertex v1, Vertex v2, Vertex v3) {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
    }

    public double computePerimeter(){
        double result = v1.computeDistance(v2);
        result += v2.computeDistance(v3);
        result += v3.computeDistance(v1);
        return result;
    }
}
