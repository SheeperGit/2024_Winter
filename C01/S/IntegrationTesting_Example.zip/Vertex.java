public class Vertex {
    double x, y;

    public Vertex(double x, double y){
        this.x = x;
        this.y = y;
    }

    public double computeDistance(Vertex other){
        return Math.sqrt(Math.pow(x-other.x,2)+Math.pow(y-other.y,2));
    }
}
