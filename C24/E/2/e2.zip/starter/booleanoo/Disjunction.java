package booleanoo;

/**
 * A binary disjunction of BooleanExpression's.
 */
public class Disjunction {
}
