package booleanoo;

/**
 * A binary if and only if of BooleanExpression's.
 */
public class IffExpression {
}
