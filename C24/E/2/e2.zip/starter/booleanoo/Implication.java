package booleanoo;

/**
 * A binary implication of BooleanExpression's.
 */
public class Implication {
}
