package booleanoo;

/**
 * A unary negation.
 */
public class Negation {
}
