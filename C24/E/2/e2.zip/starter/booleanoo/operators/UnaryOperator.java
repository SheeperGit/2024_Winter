package booleanoo.operators;

/**
 * A unary boolean operator.
 */
public UnaryOperator {
}
