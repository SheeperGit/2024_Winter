package booleanoofunc;

/**
 * A binary conjunction of BooleanExpression's.
 */
public class Conjunction {
  @Override
  public String toStringOp() {
    return Constants.AND;
  }
}
