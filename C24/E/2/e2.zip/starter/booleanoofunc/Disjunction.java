package booleanoofunc;

/**
 * A binary disjunction of BooleanExpression's.
 */
public class Disjunction {
  @Override
  public String toStringOp() {
    return Constants.OR;
  }
}
