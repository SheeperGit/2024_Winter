package booleanoofunc;

/**
 * A binary if and only if of BooleanExpression's.
 */
public class IffExpression {
  @Override
  public String toStringOp() {
    return Constants.IFF;
  }
}
