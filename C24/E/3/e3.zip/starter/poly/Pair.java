package poly;

/**
 * A Pair of X and Y.
 */
public class Pair {}
