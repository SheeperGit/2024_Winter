module SetEq where

import Set
