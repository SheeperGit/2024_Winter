package set;

/**
 * Things that can be compared for equality using method eq.
 */
public Eq{}
