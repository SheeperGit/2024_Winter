package set;

/**
 * A partial ordering.
 */
public enum PartialOrdering {
  LT, EQ, GT, INC;
}
