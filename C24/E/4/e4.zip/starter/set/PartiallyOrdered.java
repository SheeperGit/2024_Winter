package set;

/**
 * Things that have a parital order.
 */
public PartiallyOrdered{}
