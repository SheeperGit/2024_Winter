package set;


/**
 * A partially ordered Set.
 */
public PartiallyOrderedSet{}
