package set;

/**
 * Things that can be represented with a String using method show.
 */
public Show {}
