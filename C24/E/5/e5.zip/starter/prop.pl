% -*- Mode : Prolog -*- 

:- module(prop, [formula/1, eval/3, sub/3]).

